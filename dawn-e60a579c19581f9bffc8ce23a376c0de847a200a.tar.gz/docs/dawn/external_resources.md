# Dawn's external resources links

## Design Docs

- Buffer mapping dawn wire memory transfer interface design
    - https://docs.google.com/document/d/1JOhCpmJ_JyNZJtX6MVbSgxjtG1TdKORdeOGYtSfVYjk/edit?usp=sharing&resourcekey=0-1bFi47mR1jkBLdRFxcTVig