In order to use Dawn WebGPU implementation with GLFW there is some
boilerplate code needed in order to create the WebGPU surface. This repo
contains an implementation of that boilerplate which can be used by
downstream applications. It can also serve as an example of how to
integrate Dawn and GLFW if there is desire to not use this helper.
